package com.capgemini.tcc.dao;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exceptions.ClinicException;

public interface IPatientDAO {
	int addPatientDetails(PatientBean patient) throws ClinicException;

	PatientBean getPatientDetails(int patientId) throws ClinicException;
}
